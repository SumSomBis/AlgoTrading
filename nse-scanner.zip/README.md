# 📡 Daily NSE Signal Scanner

Scans Nifty 100 every weekday at ~4:15 PM IST and sends BUY / SELL / HOLD signals to Telegram (and/or email). Runs free on GitHub Actions. Every signal is logged in `scanner_output/signal_log.csv` for paper-trading review.

> Educational tool, not financial advice. Paper trade for 2–3 months before using real money.

## Setup (≈10 minutes, one time)

### 1. Create a Telegram bot
1. In Telegram, open **@BotFather** → send `/newbot` → pick a name. Copy the **token** it gives you.
2. Open your new bot and send it any message (e.g. `hi`).
3. In a browser, open `https://api.telegram.org/bot<TOKEN>/getUpdates` (put your token in).
4. Find `"chat":{"id":123456789` — that number is your **chat ID**.

### 2. Put this code on GitHub
1. Create a **private** repo on github.com (e.g. `nse-scanner`).
2. Upload all files from this folder, including the hidden `.github` folder.
   (Easiest: `git init`, `git add .`, `git commit -m init`, then push. The web uploader can skip hidden folders.)

### 3. Add your secrets
Repo → **Settings → Secrets and variables → Actions → New repository secret**:

| Name | Value |
|---|---|
| `TELEGRAM_TOKEN` | bot token from step 1 |
| `TELEGRAM_CHAT_ID` | chat ID from step 1 |

Optional email (Gmail): `EMAIL_USER` (your Gmail), `EMAIL_PASS` (a Gmail **App Password**, not your normal password), `EMAIL_TO` (where to send).

### 4. Test it
Repo → **Actions** tab → enable workflows if asked → **Daily NSE Scan → Run workflow**. You should get a Telegram message in ~2 minutes.

After that it runs automatically every weekday.

## Change settings
Edit the top of `scanner.py`: `UNIVERSE` (`NIFTY50` / `NIFTY100` / `NIFTY200`), EMA periods, risk %, etc.
Change the time in `.github/workflows/daily_scan.yml` (cron is in UTC; IST = UTC + 5:30).

## Notes
- GitHub's scheduler can run 5–30 min late on busy days.
- GitHub pauses scheduled workflows in repos with no activity for 60 days; the daily log commit keeps it active.
